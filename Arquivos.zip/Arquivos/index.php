<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <title>Manipulaçao de Arquivos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <?php
        /* Tayson Lincon de Laposte
        SC3033384 */
    ?>
</head>

<body>
    <div class="columns">
        <div class="column">
            <h2 class="title is-4">Selecione os arquivos</h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="field">    
                    <div class="file is-small is-boxed">
                    <label class="file-label">
                        <input type="file" name="files[]" id="file-input" class="file-input" accept=".pdf, .jpeg, .png" multiple>
                        <span class="file-cta">
                            <span class="file-icon">
                                <i class="fas fa-upload"></i>
                            </span>
                            <span class="file-label">
                            Escolha um arquivo
                            </span>
                        </span>
                        <span class="file-name" id="file-input-label">
                        </span>
                    </label>
                    </div>
                </div>
                <div class="field">
                    <button class="button is-link">Enviar</button>
                </div>
            </form>
        </div>

        <div class="column">
            <h2 class="title is-4">Arquivos</h2>
            <?php
                function message($message){
                    echo "<p>$message</p>";
                    die;
                }

                function reArrayFiles(&$file_post) {
                    $file_ary = array();
                    $file_count = count($file_post['name']);
                    $file_keys = array_keys($file_post);
                    for ($i=0; $i<$file_count; $i++) {
                        foreach ($file_keys as $key) {
                            $file_ary[$i][$key] = $file_post[$key][$i];
                        }
                    }
                    return $file_ary;
                }

                $uploadir = "arquivos";
                // Verificação de segurança em todos os arquivos
                if (isset($_FILES['files']['name']) && !empty($_FILES['files']['name'])) {
                    $file_ary = reArrayFiles($_FILES['files']);
                    foreach ($file_ary as $file) {
                        if (is_uploaded_file($file['tmp_name'])) {
                            $name = $file['name'];
                            $size = $file['size'];
                            $extensao = pathinfo($file['name'])['extension'];
                            if ($extensao != "pdf" && $extensao != "jpeg" & $extensao != "png")
                                message("O arquivo $name não tem o formato esperado!");
                            if ($size < 10 * 1024 && $extensao == "pdf")
                                message("O arquivo $name é inferior ao tamanho esperado!");
                            elseif ($size > 1024 * 1024 && $extensao == "pdf")
                                message("O arquivo $name é superior ao tamanho esperado!");
                            if ($size < 500 * 1024 && ($extensao == "jpeg" || $extensao == "png")) 
                                message("O arquivo $name é inferior ao tamanho esperado!");                
                        } else {
                            message("Houve um erro no recebimento do arquivo " . $file['name'] . "!");
                        }
                    }
                    // Caso verificação ok, os arquivos são salvos
                    foreach ($file_ary as $file) {
                        $unico = md5(uniqid(rand(), true));
                        $extensao = pathinfo($file['name'])['extension'];
                        $path = getcwd() . "/$uploadir/$unico.$extensao";
                        $tmp_name = $file['tmp_name'];
                        move_uploaded_file($tmp_name, $path);
                    }
                    $files = scandir(getcwd()."/$uploadir");
                    foreach ($files as $file) {
                        $filePath = "/Arquivos/$uploadir" . '/' . $file;
                        if (is_file(getcwd()."/$uploadir" . "/" . $file))
                            echo "<p><a href=$filePath download>$file</a></p>";
                    }
                }
                ?>
            </div>
    </div>
    <script>
        const fileInput = document.getElementById('file-input');
        const fileInputLabel = document.getElementById('file-input-label');

        fileInput.addEventListener('change', () => {
        if (fileInput.value != '') {
            const realPathArray = fileInput.value.split('\\');
            fileInputLabel.innerHTML = realPathArray[realPathArray.length - 1];
        }
        });
    </script>
</body>

</html>